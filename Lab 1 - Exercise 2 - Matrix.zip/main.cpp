#include <iostream>
#include "matrix.hpp"

int main()
{
    // You can test your implementation here.
    Matrix m1(4);

    std::cout << m1;

    return 0;
}
