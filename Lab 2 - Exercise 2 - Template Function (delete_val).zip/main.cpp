#include "deletearray.cpp"


using namespace std;

int main()
{
    double* double_array = new double [5];
    
    // You can test your implementation here.
    
    return 0;
}
