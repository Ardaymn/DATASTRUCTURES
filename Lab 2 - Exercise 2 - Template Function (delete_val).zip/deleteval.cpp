#include <iostream>

// Write a C++ template function to solve the following problem: 
// delete a value val from an unsorted array A[0..n-1]. Assume all values 
// in A are distinct. 
// Use the following function header:
template<class C>
void delete_val(C A[], int &n, C val);
// n is the number of elements in the array, val is the value to be deleted
// n must be decreased by one if deletion is successful

// First find the location of val in the array.
// Delete val by shifting the remaining elements to the left by one position.
// Decrement n.
template<class C>
void delete_val(C A[], int &n, C val)
{
    // TODO
    int j = 0;
    int index = 0;
    for(j=0; j<n; j++)
    {
        if(A[j] == val)
        {
            index = j;
            break;
        }
    }
    
    for(j=index; j<n-1; j++)
    {
        A[j] = A[j+1];
    }
    
    n-=1;// TODO
}


