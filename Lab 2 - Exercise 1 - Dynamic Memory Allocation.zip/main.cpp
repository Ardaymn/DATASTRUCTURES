#include "myarray.h"

using namespace std;

int main()
{
    MyArray arr_obj;
    
    
    // You can test your implementation here.
    

    return 0;
}
