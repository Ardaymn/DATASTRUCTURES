#ifndef __rational_hpp__
#define __rational_hpp__

class Rational
{
    public:
        /* Constructors */
        Rational();
        Rational(int num, int den);

        /* Public member functions */
        Rational add(Rational rhs);
        Rational multiply(Rational rhs);

        void print();

        void setNumerator(int num);
        int getNumerator();
        void setDenominator(int den);
        int getDenominator();

    private:
        /* Private member functions */
        void simplify();
        int gcd(int a, int b);

        /* Private member variables */
        int numer;
        int denom;
};

#endif // __rational_hpp__
