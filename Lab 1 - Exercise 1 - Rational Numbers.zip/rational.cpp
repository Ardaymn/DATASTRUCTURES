#include <iostream>

#include "rational.hpp"
using namespace std;

// Default (zero-argument) constructor.
Rational::Rational()
{
    numer = denom = 0;
}

// Two argument constructor.
Rational::Rational(int num, int den)
{
    /* TO-DO */
    numer=num ;
    denom = den;
    
    // Constructors are used to initialize the member variables while creating an object.
}

void Rational::setNumerator(int num)
{
    numer = num;
}

int Rational::getNumerator()
{
    /* TO-DO */
    return numer;
    
    // Getter functions can be used to access private member variables.
}

void Rational::setDenominator(int den)
{
    /* TO-DO */
    denom=den;
    // Setter functions can be used to modify private member variables.
}

int Rational::getDenominator()
{
    /* TO-DO */
    return denom;
    // Getter functions can be used to access private member variables.
}

void Rational::print()
{
    /* TO-DO */
    cout <<numer<<"/"<< denom << endl; 
    
    // The format is not evaluated, but you may print in the format: numer/denom
    // e.g., 3/4
}

Rational Rational::add(Rational rhs)
{
    Rational result;
    int n,d;
    n=(numer*(rhs.getDenominator())+(denom*(rhs.getNumerator())));
    d=denom*rhs.getDenominator();
    result.setNumerator(n);
    result.setDenominator(d);
    /* TO-DO */
    
    // Implement rational number addition.
    // e.g., a/b + c/d = ...
    
    /* */
    
    // Simplifying the rational number result before returning it.
    result.simplify();

    return result;
}

Rational Rational::multiply(Rational rhs)
{
    /* TO-DO */
    
    int y,u;
    y=(numer*rhs.getNumerator());
    u=(denom*rhs.getDenominator());
    rhs.setNumerator(y);
    rhs.setDenominator(u);
    return rhs;
    // Implement rational number multiplication.
    // e.g., a/b * c/d = ...
    
    // Simplify the rational number to return before returning it.
}

void Rational::simplify()
{
    /* TO-DO */
    int w;
    w=gcd(numer,denom);
    numer=numer/w;
    denom=denom/w;
    // Simplification of a rational is the process of reducing it in its lowest terms possible.
    // e.g., 10/15 -> 2/3
    // hint: use greatest common divisor (gcd).
}

// Calculates and returns the greatest common divisor of a and b.
int Rational::gcd(int a, int b)
{
    int c;

    if(a < 0)
        a = a * -1;
    if(b < 0)
        b = b * -1;

    while (a != 0)
    {
        c = a;
        a = b % a;
        b = c;
    }

    return b;
}
